#include "FakeFile2_testStrongComponent.h"

// strong component node1 -> node2 ->node3 -> node1
class Node1
{
private:
	Node2 n;
};