#include "FakeFile3_testStrongComponent.h"
// strong component node1 -> node2 ->node3 -> node1
class Node2
{
private:
	Node3 n;
};